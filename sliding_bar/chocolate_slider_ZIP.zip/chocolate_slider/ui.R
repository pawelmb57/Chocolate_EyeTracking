



library(shiny)
library(plotly)

runUrl( "http://www.pawelb.com/work/chocolate_shiny/chocolate_slider_ZIP.zip")




shinyUI(fluidPage(
  titlePanel("Chocolate!"),
  sidebarPanel(
    sliderInput("bins", "Participant Number:", min = 2401, max = 2417, value = 2415)
  ),
  mainPanel(
    plotlyOutput("heatPlot")
  )
))